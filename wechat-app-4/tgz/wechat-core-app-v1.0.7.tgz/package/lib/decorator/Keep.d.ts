import { ActionHandler, onDestroyIntervalDecoratorFlag } from "../module";
type OnDestroyHandlerDecorator = (target: object, propertyKey: "onDestroy", descriptor: TypedPropertyDescriptor<ActionHandler & onDestroyIntervalDecoratorFlag>) => TypedPropertyDescriptor<ActionHandler>;
export declare function KeepState(keep?: boolean): OnDestroyHandlerDecorator;
export {};
