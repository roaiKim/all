import { ActionHandler, TickIntervalDecoratorFlag } from "../module";
type OnTickHandlerDecorator = (target: object, propertyKey: "onTick", descriptor: TypedPropertyDescriptor<ActionHandler & TickIntervalDecoratorFlag>) => TypedPropertyDescriptor<ActionHandler>;
export declare function Interval(second: number): OnTickHandlerDecorator;
export {};
