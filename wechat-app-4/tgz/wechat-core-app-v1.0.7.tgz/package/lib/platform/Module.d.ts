import { AnyAction } from "redux";
import { TickIntervalDecoratorFlag, onDestroyIntervalDecoratorFlag } from "../module";
import { State } from "../reducer";
export interface ModuleLifecycleListener {
    onEnter: (params: Record<string, any> | undefined, pageName: string | undefined) => Promise<void> | void;
    onDestroy: ((pageName: string | undefined) => Promise<void> | void) & onDestroyIntervalDecoratorFlag;
    onTick: (() => Promise<void> | void) & TickIntervalDecoratorFlag;
    onShow: (params: Record<string, any> | undefined, pageName: string | undefined) => Promise<void> | void;
    dispatch: (action: AnyAction) => Promise<void> | void;
    onHide: (params: Record<string, any> | undefined, pageName: string | undefined) => Promise<void> | void;
    needAuth?: true;
    authAction?: () => void;
}
export declare class Module<RootState extends State, ModuleName extends keyof RootState["app"] & string> implements ModuleLifecycleListener {
    readonly name: ModuleName;
    readonly initialState: RootState["app"][ModuleName];
    constructor(name: ModuleName, initialState: RootState["app"][ModuleName]);
    /**
     * @description 组件安装 一个生命周期内只会运行一次  和 componentDidMount 一样
     * @param params 跳转参数
     * @param pageName 页面名称
     */
    onEnter(params: Record<string, any> | undefined, pageName: string | undefined): Promise<void> | void;
    /**
     * @description 组件销毁 一个生命周期内只会运行一次  和 componentWillUnMount 一样
     */
    onDestroy(pageName: string | undefined): Promise<void> | void;
    /**
     * @description 循环某一个 函数, 在生命周期内会一直运行 无法提前退出 直到组件销毁
     */
    onTick(): Promise<void> | void;
    /**
     * @description Taro 小程序 的 componentDidShow/useDidShow
     * @param params 跳转参数
     */
    onShow(params: Record<string, any> | undefined, pageName: string | undefined): Promise<void> | void;
    /**
     * @description Taro 小程序 的 componentDidHide/useDidHide
     * @param params 跳转参数
     */
    onHide(params: Record<string, any> | undefined, pageName: string | undefined): Promise<void> | void;
    /**
     *
     * @param action actions 调用
     */
    dispatch(action: AnyAction): Promise<void> | void;
    /**
     * @description 获取当前module的state
     */
    get state(): Readonly<RootState["app"][ModuleName]>;
    /**
     * @description 获取整个项目的state
     */
    get rootState(): Readonly<RootState>;
    setNavigationPrevented(isPrevented: boolean): void;
    /**
     *
     * @param stateOrUpdater 更新的内容 可以是对象 & function
     */
    setState<K extends keyof RootState["app"][ModuleName]>(stateOrUpdater: ((state: RootState["app"][ModuleName]) => void) | Pick<RootState["app"][ModuleName], K> | RootState["app"][ModuleName]): void;
}
