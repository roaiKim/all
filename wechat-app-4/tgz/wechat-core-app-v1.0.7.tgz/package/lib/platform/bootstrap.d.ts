import React from "react";
interface BootstrapOption {
    componentType: React.ComponentType;
    rootContainer?: HTMLElement | null;
}
export declare const LOGGER_ACTION = "@@framework/logger";
export declare const VERSION_CHECK_ACTION = "@@framework/version-check";
export declare const GLOBAL_ERROR_ACTION = "@@framework/global";
export declare const GLOBAL_PROMISE_REJECTION_ACTION = "@@framework/promise-rejection";
export declare function bootstrap(option: BootstrapOption): void;
export {};
