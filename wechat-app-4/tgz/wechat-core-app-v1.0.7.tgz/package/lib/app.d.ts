import { Store } from "redux";
import { ActionHandler } from "./module";
import { State } from "./reducer";
import { Exception } from "./exception";
interface App {
    readonly store: Store<State>;
    readonly actionHandlers: {
        [actionType: string]: ActionHandler;
    };
    errorHandler: (error: Exception) => unknown;
}
export declare const app: App;
export declare const roDispatch: import("redux").Dispatch<import("redux").UnknownAction>;
export declare const roApp: App;
export {};
