export declare function useLoadingStatus(identifier?: string): boolean;
