export function getCurrentInstance(): void;
