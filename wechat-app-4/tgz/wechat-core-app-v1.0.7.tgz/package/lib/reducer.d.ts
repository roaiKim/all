import { Action as ReduxAction, Reducer } from "redux";
interface LoadingState {
    [loading: string]: number;
}
export interface State {
    loading: LoadingState;
    navigationPrevented: boolean;
    app: Record<string, object>;
}
declare const SET_STATE_ACTION = "@@framework/setState";
export interface Action<P> extends ReduxAction<string> {
    payload: P;
    name?: typeof SET_STATE_ACTION;
}
interface SetStateActionPayload {
    module: string;
    state: any;
}
export declare function setStateAction(module: string, state: object, type: string): Action<SetStateActionPayload>;
interface LoadingActionPayload {
    identifier: string;
    show: boolean;
}
export declare const LOADING_ACTION = "@@framework/loading";
export declare function loadingAction(show: boolean, identifier?: string): Action<LoadingActionPayload>;
interface NavigationPreventionActionPayload {
    isPrevented: boolean;
}
export declare function navigationPreventionAction(isPrevented: boolean): Action<NavigationPreventionActionPayload>;
export declare function rootReducer(): Reducer<State>;
export declare function showLoading(state: State, identifier?: string): boolean;
export declare const executeMethodMiddleware: () => (next: any) => (action: Action<any>) => any;
export {};
